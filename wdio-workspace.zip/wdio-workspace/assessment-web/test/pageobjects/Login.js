const Launch = require('./Launch');

class Login extends Launch {
    
    // login page web elements
    //unameElement = $('#username');
    //passwordElement = $('#password');
    //loginButtonElement = $('.ant-btn > span');

    //unameElement = $('//input[@id="username"]');
   // passwordElement = $('//input[@id="password"]');
    //loginButtonElement = $('//button[@type="submit"]');

    get unameElement() {
        return $('#username');
    }

    get passwordElement() {
        return $('#password');
    }

    get loginButtonElement() {
        return $('.ant-btn > span');
    }





    // login method
    loginToApplication(userName, password) {
        this.unameElement().setValue(userName);
        this.passwordElement().setValue(password);
        this.loginButtonElement().click();
    }
    
    launchApplication() {

        return super.launchApplication();

    }

}

module.exports = new Login();