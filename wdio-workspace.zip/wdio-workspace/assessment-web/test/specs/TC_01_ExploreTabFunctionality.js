const Login = require('../pageobjects/Login');
const Explore = require('../pageobjects/Explore');

describe('Test Case - Explore Functionality', () => {
    
    it('LAUNCH STEPS', () =>  {
        
        // lauch application
        Login.launchApplication();
        // assertions
        const label = $('//span[@class="antd-pro-layouts-user-layout-title" and text()="Lucidum"]');
        expect(label).toBeDisplayed();
        const button = $('//button[@type="submit"]');
        expect(button).toBeDisplayed();

    }); 

     it('LOGIN STEPS', () => {
        
        // login to application
        Login.unameElement.addValue('test');
        Login.passwordElement.addValue('Lucidum!CMDBio@Demo');
        Login.loginButtonElement.click();
        // assertions
        const charts = $('//div[@class="ant-row"]')
        expect(charts).toBeDisplayed();
        const dataFlowcl = $('//canvas[@data-zr-dom-id="zr_0"]')
        expect(charts).toBeDisplayed();
        

    });

    it('EXPLORE TAB STEPS', () => {
        
        // navigate to explore tab
        Explore.exploreTab.click();
        // assertion
        expect(Explore.searchDropdown).toBeDisplayed();

        // run query
        Explore.searchDropdown.highlight();
        Explore.searchDropdown.click();
        Explore.filterFieldDropdown.click();
        Explore.filterOperatorDropdown.click();
        Explore.filterValueInput.click();
        Explore.runButton.click();


        // Login.passwordElement.addValue('Lucidum!CMDBio@Demo');
        // Login.loginButtonElement.click();
        // // assertions
        // const charts = $('//div[@class="ant-row"]')
        // expect(charts).toBeDisplayed();
        // const dataFlowcl = $('//canvas[@data-zr-dom-id="zr_0"]')
        // expect(charts).toBeDisplayed();

    });

});