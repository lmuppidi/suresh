module.exports = class Explore {

    // explore tab web elements
    get exploreTab() {
        return $('.antd-pro-components-headers-index-headerIcon=Explore');
    } 

    // query run web elements
    get searchDropdown() {
        return $('//*[contains(@class,"ant-select-selection-item") and text()="Search User (Last"]');
    }
    
   get filterFieldDropdown() {
       return $('//div[contains(@class,"ant-select-item-option-content" and text()="# of CPU Cores"');
   }

    get filterOperatorDropdown() {
        return $('//div[contains(@class,"ant-select-item-option-content" and text()="is equal to"');
    }

    get filterValueInput() {
        return $('//div[contains(@class,"ant-select-item-option-content" and text()="4.0"');
    }    
    
    get runButton() {
        return $('//button[type="submit"]');
    }
    
     // navigate to explore tab
     navigateToTabExplore() {
         
        this.exploreTab.click();
         expect(this.searchDropdown).should('be.visible');

     }
     
     queryRun() {

        this.searchDropdown.click();
        this.filterFieldDropdown.click();
        this.filterOperatorDropdown.click();
        this.filterValueInput.click();
        this.runButton.click();
        

       
    }


}