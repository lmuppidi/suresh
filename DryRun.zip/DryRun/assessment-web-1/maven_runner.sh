#!/bin/bash
echo "START: Running tests..."
mvn clean verify