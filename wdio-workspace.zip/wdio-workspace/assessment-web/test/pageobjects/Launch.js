module.exports = class Launch {

    // application lunch method   
    launchApplication () {
        return browser.url();
    }

}