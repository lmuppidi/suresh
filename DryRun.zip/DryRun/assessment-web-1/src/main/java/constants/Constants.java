package constants;

public class Constants {
	
	
	public static long PAGE_LOAD_TIME = 30;
	public static long IMPLICIT_WAIT = 30;
	

}
